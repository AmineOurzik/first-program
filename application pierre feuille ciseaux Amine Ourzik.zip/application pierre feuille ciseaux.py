import tkinter as tk
from random import *

#configuration des fonctions

dict_outils ={
    -1: "Pierre",
    0: "Feuille",
    1: "Ciseaux"
}

def play(outil):
    bouton_arret()
    comp_pick = randint(-1,1)
    player.config(text = dict_outils[outil])
    ordinateur.config(text = dict_outils[comp_pick])
    if outil == -1:
        image_player.config(image= image_pierre)
        if comp_pick == -1:
            image_ordinateur.config(image= image_pierre)
            texte.config(text= "Egalité🙄")
        elif comp_pick == 0:
            image_ordinateur.config(image=image_feuille)
            texte.config(text= "Perdue😭")
        else:
            image_ordinateur.config(image= image_ciseaux)
            texte.config(text= "Gagné !🗣️🔥")
    elif outil == 0:
        image_player.config(image= image_feuille)
        if comp_pick == -1:
            image_ordinateur.config(image= image_pierre)
            texte.config(text= "Gagné !🗣️🔥")
        elif comp_pick == 0:
            image_ordinateur.config(image=image_feuille)
            texte.config(text= "Egalité🙄")
        else:
            image_ordinateur.config(image= image_ciseaux)
            texte.config(text= "Perdue😭")
    else:
        image_player.config(image= image_ciseaux)
        if comp_pick == -1:
            image_ordinateur.config(image= image_pierre)
            texte.config(text= "Perdue😭")
        elif comp_pick == 0:
            image_ordinateur.config(image=image_feuille)
            texte.config(text= "Gagné !🗣️🔥")
        else:
            image_ordinateur.config(image= image_ciseaux)
            texte.config(text= "Egalité🙄")

def bouton_arret():
    button_pierre["state"]= tk.DISABLED
    button_feuille["state"]= tk.DISABLED
    button_ciseaux["state"]= tk.DISABLED

def reset():
    button_pierre["state"]= tk.NORMAL
    button_feuille["state"]= tk.NORMAL
    button_ciseaux["state"]= tk.NORMAL
    texte.config(text = "Choisissez votre outil")
    player.config(text= "Joueur")
    ordinateur.config(text="Ordinateur")
    image_player.config(image=image_point_d_interrogation)
    image_ordinateur.config(image=image_point_d_interrogation)


#configuration de la fenêtre
window = tk.Tk()
window.title("Jeu de pierre, feuille, ciseaux")
window_width = 725
window_height = 500
screen_width = window.winfo_screenwidth()
screen_height = window.winfo_screenheight()
center_x = int(screen_width/2 - window_width / 2)
center_y = int(screen_height/2 - window_height / 2)
window.geometry(f"{window_width}x{window_height}+{center_x}+{center_y}")
window.iconbitmap("icone jeu.ico")
bg_color = "#4b3832"
window.configure(bg= bg_color)
window.columnconfigure((0,1,2,3,4,5,6), weight=1)
window.rowconfigure((0,1,2,3,4,5,6), weight=1)

#inisialisation des images
image_point_d_interrogation = tk.PhotoImage(file="point-dinterrogation.png")
image_point_d_interrogation = image_point_d_interrogation.zoom(4)
image_point_d_interrogation = image_point_d_interrogation.subsample(16)
image_pierre = tk.PhotoImage(file="Pierre.png")
image_pierre = image_pierre.zoom(4)
image_pierre = image_pierre.subsample(16)
image_feuille = tk.PhotoImage(file="Feuille.png")
image_feuille = image_feuille.zoom(4)
image_feuille = image_feuille.subsample(16)
image_ciseaux = tk.PhotoImage(file="Ciseaux.png")
image_ciseaux = image_ciseaux.zoom(4)
image_ciseaux = image_ciseaux.subsample(16)
image_exit = tk.PhotoImage(file="exit.png")
image_exit = image_exit.zoom(4)
image_exit = image_exit.subsample(24)


#configuration des éléments
titre = tk.Label(
    master = window, 
    text ="Pierre, Feuille, Ciseaux", 
    font = ("Cooper Black", 22),
    relief = tk.GROOVE,
    borderwidth= 6,
    bg = "#fff4e6",
    fg = "#3c2f2f"
)

button_exit = tk.Button(
    master = window,
    image = image_exit,
    command = window.destroy,
    borderwidth= 0,
    bg = bg_color,
    activebackground= bg_color
)

image_player = tk.Label(
    master = window,
    image=image_point_d_interrogation,
    bg= bg_color
)
image_ordinateur = tk.Label(
    master = window,
    image=image_point_d_interrogation,
    bg=bg_color
)

player = tk.Label(
    master = window,
    text="Joueur",
    font= ("Showcard Gothic", 18),
    bg= bg_color,
    fg= "#fff4e6",
    width= 20
)
vs = tk.Label(
    master = window,
    text="VS",
    font= ("Showcard Gothic", 26),
    bg= bg_color,
    fg= "#be9b7b"
)

ordinateur = tk.Label(
    master = window,
    text="Ordinateur",
    font= ("Showcard Gothic", 18),
    bg= bg_color,
    fg= "#fff4e6",
    width= 20
)
texte = tk.Label(
    master= window, 
    text = "Choisissez votre outil",
    font=("Arial", 16),
    bg= "#fff4e6",
    fg= "#854442",
    relief= tk.SOLID,
    borderwidth= 2
)
button_pierre = tk.Button(
    master = window,
    text = "Pierre",
    font = ("Berlin Sans FB", 18),
    bg= "#be9b7b",
    fg= "#3c2f2f",
    borderwidth= 2,
    command= lambda : play(-1)
)
button_feuille = tk.Button(
    master = window,
    text = "Feuille",
    font = ("Berlin Sans FB", 18),
    bg= "#be9b7b",
    fg= "#3c2f2f",
    borderwidth= 2,
    command= lambda: play(0)
)
button_ciseaux = tk.Button(
    master = window,
    text = "Ciseaux",
    font = ("Berlin Sans FB", 18),
    bg= "#be9b7b",
    fg= "#3c2f2f",
    borderwidth= 2,
    command= lambda: play(1)
)
button_reset = tk.Button(
    master= window,
    text= "Reset",
    font = ("Berlin Sans FB", 22),
    bg = "#fff4e6",
    fg = "#854442",
    borderwidth= 3,
    relief = tk.SOLID,
    command = reset
)


#placement des éléments
titre.grid(row=0, column=2, sticky="n", columnspan= 3)
button_exit.grid(row= 0, column= 4, sticky= "e")
image_player.grid(row=2, column=2)
image_ordinateur.grid(row=2, column= 4)
player.grid(column=2, row= 3)
vs.grid(column=3, row= 3)
ordinateur.grid(column= 4, row= 3)
texte.grid(column= 2, row=4, columnspan=3)
button_pierre.grid(column=2, row=5)
button_feuille.grid(column=3, row=5)
button_ciseaux.grid(column=4, row= 5)
button_reset.grid(column=3, row= 6)


window.mainloop()